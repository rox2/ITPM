﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Code_Complexity
{
    public partial class @break : MetroFramework.Forms.MetroForm
    {
        public @break()
        {
            InitializeComponent();
        }

        private void break_Load(object sender, EventArgs e)
        {

        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            select sl = new select();
            sl.ShowDialog();

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            customise cs = new customise();
            cs.ShowDialog();
        }
    }
}
