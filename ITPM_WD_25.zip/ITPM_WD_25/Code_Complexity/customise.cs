﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Code_Complexity
{
    public partial class customise : MetroFramework.Forms.MetroForm
    {
        public customise()
        {
            InitializeComponent();
        }

        private void customise_Load(object sender, EventArgs e)
        {

        }

        private void metroTextBox7_Click(object sender, EventArgs e)
        {

        }
    }
}
