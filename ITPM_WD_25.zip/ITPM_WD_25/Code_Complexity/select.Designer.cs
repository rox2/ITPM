﻿namespace Code_Complexity
{
    partial class select
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroRadioButton1 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton2 = new MetroFramework.Controls.MetroRadioButton();
            this.txtFileName = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.txtOutput = new MetroFramework.Controls.MetroTextBox();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.txtMultiFile = new MetroFramework.Controls.MetroTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroButton2);
            this.groupBox1.Controls.Add(this.metroButton1);
            this.groupBox1.Controls.Add(this.txtFileName);
            this.groupBox1.Controls.Add(this.metroRadioButton2);
            this.groupBox1.Controls.Add(this.metroRadioButton1);
            this.groupBox1.Location = new System.Drawing.Point(23, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(337, 220);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SELECTIONS";
            // 
            // metroRadioButton1
            // 
            this.metroRadioButton1.AutoSize = true;
            this.metroRadioButton1.FontSize = MetroFramework.MetroCheckBoxSize.Tall;
            this.metroRadioButton1.Location = new System.Drawing.Point(18, 34);
            this.metroRadioButton1.Name = "metroRadioButton1";
            this.metroRadioButton1.Size = new System.Drawing.Size(135, 25);
            this.metroRadioButton1.TabIndex = 0;
            this.metroRadioButton1.Text = "CHOOSE FILE";
            this.metroRadioButton1.UseSelectable = true;
            // 
            // metroRadioButton2
            // 
            this.metroRadioButton2.AutoSize = true;
            this.metroRadioButton2.FontSize = MetroFramework.MetroCheckBoxSize.Tall;
            this.metroRadioButton2.Location = new System.Drawing.Point(18, 182);
            this.metroRadioButton2.Name = "metroRadioButton2";
            this.metroRadioButton2.Size = new System.Drawing.Size(129, 25);
            this.metroRadioButton2.TabIndex = 0;
            this.metroRadioButton2.Text = "INPUT CODE";
            this.metroRadioButton2.UseSelectable = true;
            // 
            // txtFileName
            // 
            // 
            // 
            // 
            this.txtFileName.CustomButton.Image = null;
            this.txtFileName.CustomButton.Location = new System.Drawing.Point(230, 1);
            this.txtFileName.CustomButton.Name = "";
            this.txtFileName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtFileName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtFileName.CustomButton.TabIndex = 1;
            this.txtFileName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtFileName.CustomButton.UseSelectable = true;
            this.txtFileName.CustomButton.Visible = false;
            this.txtFileName.Lines = new string[0];
            this.txtFileName.Location = new System.Drawing.Point(37, 74);
            this.txtFileName.MaxLength = 32767;
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.PasswordChar = '\0';
            this.txtFileName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFileName.SelectedText = "";
            this.txtFileName.SelectionLength = 0;
            this.txtFileName.SelectionStart = 0;
            this.txtFileName.ShortcutsEnabled = true;
            this.txtFileName.Size = new System.Drawing.Size(252, 23);
            this.txtFileName.TabIndex = 1;
            this.txtFileName.UseSelectable = true;
            this.txtFileName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtFileName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtFileName.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(37, 114);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(94, 47);
            this.metroButton1.TabIndex = 2;
            this.metroButton1.Text = "CHOOSE";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(195, 114);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(94, 47);
            this.metroButton2.TabIndex = 2;
            this.metroButton2.Text = "OK";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // txtOutput
            // 
            // 
            // 
            // 
            this.txtOutput.CustomButton.Image = null;
            this.txtOutput.CustomButton.Location = new System.Drawing.Point(-61, 2);
            this.txtOutput.CustomButton.Name = "";
            this.txtOutput.CustomButton.Size = new System.Drawing.Size(359, 359);
            this.txtOutput.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtOutput.CustomButton.TabIndex = 1;
            this.txtOutput.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtOutput.CustomButton.UseSelectable = true;
            this.txtOutput.CustomButton.Visible = false;
            this.txtOutput.Lines = new string[] {
        "CHOOSED FILES OR PASTE YOUR CODE HERE..."};
            this.txtOutput.Location = new System.Drawing.Point(476, 63);
            this.txtOutput.MaxLength = 32767;
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.PasswordChar = '\0';
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtOutput.SelectedText = "";
            this.txtOutput.SelectionLength = 0;
            this.txtOutput.SelectionStart = 0;
            this.txtOutput.ShortcutsEnabled = true;
            this.txtOutput.Size = new System.Drawing.Size(301, 364);
            this.txtOutput.TabIndex = 3;
            this.txtOutput.Text = "CHOOSED FILES OR PASTE YOUR CODE HERE...";
            this.txtOutput.UseSelectable = true;
            this.txtOutput.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtOutput.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Location = new System.Drawing.Point(366, 142);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(104, 102);
            this.metroTile3.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTile3.TabIndex = 2;
            this.metroTile3.Text = "PROCESS";
            this.metroTile3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.metroTile3.TileImage = global::Code_Complexity.Properties.Resources.unnamed;
            this.metroTile3.TileImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroTile3.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.metroTile3.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.metroTile3.UseSelectable = true;
            this.metroTile3.Click += new System.EventHandler(this.metroTile3_Click);
            // 
            // txtMultiFile
            // 
            // 
            // 
            // 
            this.txtMultiFile.CustomButton.Image = null;
            this.txtMultiFile.CustomButton.Location = new System.Drawing.Point(162, 1);
            this.txtMultiFile.CustomButton.Name = "";
            this.txtMultiFile.CustomButton.Size = new System.Drawing.Size(89, 89);
            this.txtMultiFile.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtMultiFile.CustomButton.TabIndex = 1;
            this.txtMultiFile.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtMultiFile.CustomButton.UseSelectable = true;
            this.txtMultiFile.CustomButton.Visible = false;
            this.txtMultiFile.Lines = new string[0];
            this.txtMultiFile.Location = new System.Drawing.Point(18, 19);
            this.txtMultiFile.MaxLength = 32767;
            this.txtMultiFile.Multiline = true;
            this.txtMultiFile.Name = "txtMultiFile";
            this.txtMultiFile.PasswordChar = '\0';
            this.txtMultiFile.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtMultiFile.SelectedText = "";
            this.txtMultiFile.SelectionLength = 0;
            this.txtMultiFile.SelectionStart = 0;
            this.txtMultiFile.ShortcutsEnabled = true;
            this.txtMultiFile.Size = new System.Drawing.Size(378, 117);
            this.txtMultiFile.TabIndex = 1;
            this.txtMultiFile.UseSelectable = true;
            this.txtMultiFile.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtMultiFile.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtMultiFile.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMultiFile);
            this.groupBox2.Location = new System.Drawing.Point(23, 305);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(421, 150);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SELECTED FILE NAMES";
            // 
            // select
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 521);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.metroTile3);
            this.Controls.Add(this.groupBox1);
            this.Name = "select";
            this.Text = "SELECT";
            this.Load += new System.EventHandler(this.select_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton1;
        private MetroFramework.Controls.MetroTextBox txtFileName;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton2;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroTile metroTile3;
        private MetroFramework.Controls.MetroTextBox txtOutput;
        private MetroFramework.Controls.MetroTextBox txtMultiFile;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}