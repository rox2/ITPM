﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Code_Complexity
{
    public partial class select : MetroFramework.Forms.MetroForm
    {
        public select()
        {
            InitializeComponent();
        }

        private void select_Load(object sender, EventArgs e)
        {

        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void metroTile3_Click(object sender, EventArgs e)
        {
            @break bk = new @break();
            bk.ShowDialog();
        }

        private async void metroButton1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Text Documents|*.txt*",ValidateNames = true, Multiselect = false})
            { 
                if(ofd.ShowDialog() == DialogResult.OK)
                {
                    using (StreamReader sr = new StreamReader(ofd.FileName))
                    {
                        txtOutput.Text = await sr.ReadToEndAsync();
                    }
                }

                txtFileName.Text = ofd.FileName;

            }


        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            txtMultiFile.Text = txtMultiFile.Text + Environment.NewLine + txtFileName.Text;
        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
