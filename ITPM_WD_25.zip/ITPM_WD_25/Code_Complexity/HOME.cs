﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Code_Complexity
{
    public partial class HOME : MetroFramework.Forms.MetroForm
    {
        public HOME()
        {
            InitializeComponent();
        }

        private void HOME_Load(object sender, EventArgs e)
        {

        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            select slct = new select();
            slct.ShowDialog();
        }

        private void metroTile7_Click(object sender, EventArgs e)
        {
            settings st = new settings();
            st.ShowDialog();

        }
    }
}
